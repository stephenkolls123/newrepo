"""
The flask application package.
"""

from flask import Flask
app = Flask(__name__)

import SKollsPY5_3.views
